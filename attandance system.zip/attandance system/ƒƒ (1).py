import cv2
from tensorflow import keras
import numpy as np

# Load the pre-trained face detection model
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

# Load the trained object detection model
model = keras.models.load_model('modjjel.h5')

# Define the list of class names
classes = ['Abdulaziz', 'Abdulrahman', 'abdulrahman yones', 'afnan', 'Ahmed', 'Anas', 'Besan', 'HalaF', 'hassan', 'Hazem', 'Maria', 'Marwa', 'Mohamed', 'Mohamed Thabab', 'Omer', 'Sanad', 'shahad', 'shoq', 'tariq']  # Replace with your own class names

# Open a video capture device
cap = cv2.VideoCapture(0)  # 0 for the default camera, or provide a file path for a video file

# Loop through the video frames
while True:
    # Read a frame from the video capture device
    ret, frame = cap.read()
    
    # Detect faces in the frame using the Haar Cascades face detection model
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    
    # Loop through the detected faces
    for (x, y, w, h) in faces:
        # Extract the face from the frame
        face = frame[y:y+h, x:x+w]
        
        # Preprocess the face
        face = cv2.resize(face, (224, 224))
        face = face.astype('float32') / 255.0
        face = np.expand_dims(face, axis=0)
        
        # Make a prediction on the face
        pred = model.predict(face)
        class_idx = np.argmax(pred)
        class_label = classes[class_idx]
        
        # Draw a bounding box around the detected face
        cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
        
        # Display the predicted class label above the bounding box
        cv2.putText(frame, class_label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
    
    # Display the processed frame
    cv2.imshow('frame', frame)
    
    # Wait for a key event to exit
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture device and close the display window
cap.release()
cv2.destroyAllWindows()